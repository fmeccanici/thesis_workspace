^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package pal_gripper_description
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.0.8 (2016-09-20)
------------------
* use box for fingers' collision model
* Contributors: Jordi Pages

0.0.7 (2016-07-28)
------------------

0.0.6 (2016-07-22)
------------------
* remove grasping hack macro and tune friction
* update meshes and inertia matrices
* Contributors: Jordi Pages

0.0.5 (2016-06-15)
------------------
* Change gripper limit to 0.045
* Contributors: Victor Lopez

0.0.4 (2016-06-13)
------------------
* Fix safety joint limit
* Contributors: Sam Pfeiffer

0.0.3 (2016-06-13)
------------------
* Added safety controller values
* Contributors: Sam Pfeiffer

0.0.2 (2016-06-10)
------------------
* Added install rules
* Contributors: Hilario Tome

0.0.1 (2016-06-01)
------------------
* Initial version
* Contributors: Sam Pfeiffer
